<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table display nowrap" style="width:100%">
    <thead>
        <th>Fecha Emi.</th>
        <th>Fecha Ven.</th>
        <th>Fecha Pago</th>
        <th>Cuota</th>
        <th>Mora</th>
        <th>Saldo</th>
        <th>Tipo</th>
        <th>Status</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $ctacon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cc->fe_emision); ?></td>
                <td><?php echo e($cc->fe_vencimiento); ?></td>
                <td><?php echo e($cc->fe_pago); ?></td>
                <td><?php echo e($cc->mo_cuota); ?></td>
                <td><?php echo e($cc->mora_cuota); ?></td>
                <td><?php echo e($cc->saldo_cuota); ?></td>
                <td><?php echo e($cc->tipo); ?></td>
                <td><?php echo e($cc->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable({
                fixedHeader: true,
                //responsive: true
                responsive:{
                    details:{
                        display: $.fn.dataTable.Responsive.display.modal( {
                            header: function ( row ) {
                                var data = row.data();
                                return 'Details for '+data[0]+' '+data[1];
                            }
                        } ),
                        renderer: $.fn.dataTable.Responsive.renderer.tableAll()
                    }
                }
            });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/viviendas/partials/list-ctacon.blade.php ENDPATH**/ ?>