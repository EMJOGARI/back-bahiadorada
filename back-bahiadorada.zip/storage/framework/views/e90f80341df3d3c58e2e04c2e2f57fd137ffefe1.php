<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('name', 'Nombre del Permiso'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder'=>'Nombre...', 'value'=>'<?php echo e($permissions->name); ?>','required' => 'required']); ?>

        </div>
    </div>
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('module', 'Modulo'); ?>

            <?php echo Form::text('module', null, ['class'=>'form-control', 'placeholder'=>'Modulo...','required' => 'required']); ?>

        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('description', 'Descripción'); ?>

            <?php echo Form::textarea('description', null, ['class'=>'form-control', 'rows' => 2, 'cols' => 40, 'placeholder'=>'Descripción...']); ?>

        </div>
    </div>

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo e(Form::button(
                '<i class="fa fa-save"></i> Guardar',
                    [
                        'type' => 'submit',
                        'class' => 'btn btn-primary btn-sm',
                        'data-toggle' => 'tooltip',
                        'title' => 'Guardar'
                    ]
            )); ?>

            <?php echo e(Form::button(
                '<i class="fa fa-close"></i> Cancelar',
                    [
                        'onclick'=>'history.back()',
                        'type' => 'reset',
                        'class' => 'btn btn-danger btn-sm',
                        'data-toggle' => 'tooltip',
                        'title' => 'Cancelar'
                    ]
            )); ?>

        </div>
    </div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script>
    /** Referencia http://1000hz.github.io/bootstrap-validator/ */
    $('#form').validator()
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles-permisos\resources\views/permisos/partials/form.blade.php ENDPATH**/ ?>