<?php $__env->startSection('htmlheader_title'); ?>
	Categorias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	Categorias
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">

				<!-- Default box -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Lista Categoria </h3>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.create')): ?>
							<a href="<?php echo e(url('category/create')); ?>" class="pull-right">
								<?php echo e(Form::button(
									'<i class="fa fa-plus"></i> Nueva Categoria',
										[
											'type' => 'submit',
											'class' => 'btn btn-primary btn-sm',
											'data-toggle' => 'tooltip',
											'title' => 'Nuevo'
										]
								)); ?>

							</a>
						<?php endif; ?>
					</div>
					<div class="box-body">
						<?php echo $__env->make('category.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\roles-permisos\resources\views/category/index.blade.php ENDPATH**/ ?>