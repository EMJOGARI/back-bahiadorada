
<div style="width: 100%;text-align: center;">
	<br>
	<br>
	<h2>Hola <i>{{ $data->receiver }}</i></h2>
</div>

<div style="width: 100%; text-align: center;">
	<img src="{{ asset('public/img/mailing.jpg') }}"  style="width: max-content" alt="">
</div>
