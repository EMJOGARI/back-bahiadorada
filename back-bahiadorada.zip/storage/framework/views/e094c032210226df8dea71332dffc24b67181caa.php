<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table display nowrap" style="width:100%">
    <thead>
        <th width="10%">Persona</th>
        <th width="60%">Nombre</th>
        <th width="10%">Vivienda</th>
        <th width="20%">Acciones</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="text-center"><?php echo e($dat->id_usuario); ?></td>
                <td><?php echo e($dat->name); ?></td>
                <td class="text-center"><?php echo e($dat->vivienda); ?></td>
                <td class="text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vivienda.read')): ?>
                        <a href="<?php echo e(URL::action('ViviendasController@show',encrypt($dat->id_user))); ?>">
                            <?php echo e(Form::button(
                                '<i class="fa fa-eye"></i>',
                                    [
                                        'type' => 'submit',
                                        'class' => 'btn btn-primary btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Ver'
                                    ]
                            )); ?>

                        </a>
                    <?php endif; ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
     $(document).ready(function() {
        var table = $('.data-table').DataTable({
                fixedHeader: true,
                //responsive: true
                responsive:{
                    details:{
                        display: $.fn.dataTable.Responsive.display.modal( {
                            header: function ( row ) {
                                var data = row.data();
                                return 'Details for '+data[0]+' '+data[1];
                            }
                        } ),
                        renderer: $.fn.dataTable.Responsive.renderer.tableAll()
                    }
                }
            });
    });
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/viviendas/partials/list.blade.php ENDPATH**/ ?>