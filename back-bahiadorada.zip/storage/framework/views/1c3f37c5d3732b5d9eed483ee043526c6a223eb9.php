<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(trans('adminlte_lang::message.header')); ?></li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e(Request::is('home') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('home')); ?>">
                    <i class='fa fa-home'></i>
                    <span>Inicio</span>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('company.list')): ?>
            <li class="<?php echo e(Request::is('company*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('company')); ?>">
                    <i class='fa fa-building-o'></i>
                    <span>Empresas</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('branchoffice.list')): ?>
            <li class="<?php echo e(Request::is('branchoffice*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('branchoffice')); ?>">
                    <i class='fa fa-building-o'></i>
                    <span>Sucursales</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['product.list'])): ?>
            <li class="treeview <?php echo e(Request::is('product.article*') || Request::is('product.category*') ? 'active' : ''); ?>">
                <a href="#">
                    <i class='fa fa-plus'></i>
                    <span>Productos</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product.list')): ?>
                    <li class="<?php echo e(Request::is('product.article*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('product/article')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Productos</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.list')): ?>
            <li class="<?php echo e(Request::is('category*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('category')); ?>">
                    <i class='fa fa-list-ul'></i>
                    <span>Categorias</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sector.list')): ?>
            <li class="<?php echo e(Request::is('sector*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('sector')); ?>">
                    <i class='fa fa-circle-o'></i>
                    <span>Sectores</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('contact.list')): ?>
            <li class="<?php echo e(Request::is('contact*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('contact')); ?>">
                    <i class='fa fa-address-card'></i>
                    <span>Contactos</span>
                </a>
            </li>
            <?php endif; ?>           
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user.list','role.list','permission.list'])): ?>
            <li class="treeview <?php echo e(Request::is('usuarios*') || Request::is('roles*') || Request::is('permisos*') ? 'active' : ''); ?>">
                <a href="#">
                    <i class='fa fa-users'></i>
                    <span>Usuarios</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.list')): ?>
                    <li class="<?php echo e(Request::is('usuarios*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('usuarios')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Usuarios</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.list')): ?>
                    <li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('roles')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Roles</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.list')): ?>
                    <li class="<?php echo e(Request::is('permisos*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('permisos')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Permisos</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/vendor/adminlte/layouts/partials/sidebar.blade.php ENDPATH**/ ?>