<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table">
    <thead>
        <th width="10%">ID</th>
        <th width="20%">Rol</th>
        <th width="20%">Nombre</th>
        <th width="30%">E-mail</th>

      </thead>
    <tbody>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->id); ?></td>
                <td><?php echo e($usuario->rol); ?></td>
                <td><?php echo e($usuario->name); ?></td>
                <td><?php echo e($usuario->email); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable( {
            fixedHeader: true
        } );
    } );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/import/users/partials/list.blade.php ENDPATH**/ ?>