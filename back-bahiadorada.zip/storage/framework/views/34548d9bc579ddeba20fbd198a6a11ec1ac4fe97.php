<div class="row">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<?php echo Form::label('name', '* Nombre'); ?>

			<?php echo Form::text('name', null, ['class'=>'form-control', 'value'=>'<?php echo e($usuario->nombre); ?>', 'required' => 'required']); ?>

		</div>
	</div>

	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
		<div class="form-group">
			<?php echo Form::label('email', '* E-mail'); ?>

			<?php echo Form::email('email', null, ['class'=>'form-control', 'value'=>'<?php echo e($usuario->email); ?>', 'required' => 'required', 'disable']); ?>

		</div>
	</div>
	<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<?php echo Form::label('password', 'Nuevo password'); ?>

			<?php echo Form::password('password', ['class'=>'form-control']); ?>

		</div>
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
		<div class="form-group">
			<?php echo Form::label('password_conf', 'Confirmar password'); ?>

			<?php echo Form::password('password_conf', ['class'=>'form-control']); ?>

		</div>
	</div>
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<div class="form-group">
			<?php echo e(Form::button(
				'<i class="fa fa-save"></i> Guardar',
				[
				'type' => 'submit',
				'class' => 'btn btn-primary btn-sm',
				'data-toggle' => 'tooltip',
				'title' => 'Guardar'
				]
				)); ?>

				<?php echo e(Form::button(
					'<i class="fa fa-close"></i> Cancelar',
					[
					'onclick'=>'history.back()',
					'type' => 'reset',
					'class' => 'btn btn-danger btn-sm',
					'data-toggle' => 'tooltip',
					'title' => 'Cancelar'
					]
					)); ?>

				</div>
			</div>
		</div>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script>
    /** Referencia http://1000hz.github.io/bootstrap-validator/ */
    $('#form').validator()
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/user/partials/form-pass.blade.php ENDPATH**/ ?>