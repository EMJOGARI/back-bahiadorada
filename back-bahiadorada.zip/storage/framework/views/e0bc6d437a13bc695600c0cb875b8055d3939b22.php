<div class="row">
    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('name', 'Nombre Rol'); ?>

            <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder'=>'Nombre Rol...','required' => 'required']); ?>

        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="form-group">
            <?php echo Form::label('description', 'Descripción'); ?>

            <?php echo Form::textarea('description', null, ['class'=>'form-control', 'rows' => 2, 'cols' => 40, 'placeholder'=>'Descripción...']); ?>

        </div>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <h4>Asignar Permisos</h4>
    </div>
    <div class="row list-permissions">
        <?php
            $module = '';
        ?>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($module == ''): ?>
                <?php
                    $module = $permission->module;
                ?>
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                <h3><?php echo e($permission->module); ?></h3>
            <?php elseif($module !== $permission->module): ?>
                <?php
                    $module = $permission->module;
                ?>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                <h3><?php echo e($permission->module); ?></h3>
            <?php endif; ?>

            <p><?php echo e(Form::checkbox('permissions[]', $permission->name, false)); ?> <?php echo e($permission->description); ?></p>

            <?php if($loop->last): ?>
                </div>
            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <br><br>
        <div class="form-group">
            <?php echo e(Form::button(
                '<i class="fa fa-save"></i> Guardar',
                    [
                        'type' => 'submit',
                        'class' => 'btn btn-primary btn-sm',
                        'data-toggle' => 'tooltip',
                        'title' => 'Guardar'
                    ]
            )); ?>

            <?php echo e(Form::button(
                '<i class="fa fa-close"></i> Cancelar',
                    [
                        'onclick'=>'history.back()',
                        'type' => 'reset',
                        'class' => 'btn btn-danger btn-sm',
                        'data-toggle' => 'tooltip',
                        'title' => 'Cancelar'
                    ]
            )); ?>

        </div>
    </div>
</div>


<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script>
    /** Referencia http://1000hz.github.io/bootstrap-validator/ */
    $('#form').validator()
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles-permisos\resources\views/roles/partials/form.blade.php ENDPATH**/ ?>