<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/public/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table">
    <thead>
        <th width="10%">ID</th>
        <th width="20%">Nombre</th>
        <th width="30%">E-mail</th>
        <th width="20%">Rol</th>
        <th width="20%">Acciones</th>
      </thead>
    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($usuario->id); ?></td>
                <td><?php echo e($usuario->name); ?></td>
                <td><?php echo e($usuario->email); ?></td>
                <td><?php echo e($usuario->roles->implode('name', ', ')); ?></td>
                <td class="text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.update')): ?>
                        <a href="<?php echo e(URL::action('UsersController@edit',encrypt($usuario->id))); ?>">
                            <?php echo e(Form::button(
                                '<i class="fa fa-edit"></i>',
                                    [
                                        'type' => 'submit',
                                        'class' => 'btn btn-primary btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Editar'
                                    ]
                            )); ?>

                        </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.delete')): ?>
                        <a href="#"
                            data-target="#modal-delete-<?php echo e($usuario->id); ?>"
                            data-toggle="modal" >
                            <?php echo e(Form::button(
                                '<i class="fa fa-trash"></i>',
                                    [
                                        'class' => 'btn btn-warning btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Eliminar'
                                    ]
                            )); ?>

                        </a>

                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal modal-warning fade" id="modal-delete-<?php echo e($usuario->id); ?>">
        <?php echo Form::open(['method'=>'delete', 'route'=>['usuarios.destroy', encrypt($usuario->id)]]); ?>

            <?php echo e(Form::token()); ?>

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                                <h4 class="modal-title">Eliminar usuario</h4>
                        </div>
                        <div class="modal-body">
                            <p>Confirme si desea Eliminar el Usuario <strong><?php echo e($usuario->name); ?></strong></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-outline">Eliminar</button>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <?php echo Form::close(); ?>

        <!-- /.modal-dialog -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/public/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable( {
            fixedHeader: true
        } );
    } );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/usuarios/partials/list.blade.php ENDPATH**/ ?>