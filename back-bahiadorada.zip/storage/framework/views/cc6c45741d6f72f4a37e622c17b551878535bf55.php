<?php $__env->startSection('htmlheader_title'); ?>
	Importar Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Importar Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">
        <div class="col-md-12">

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> Importar Usuarios</h3>
                </div>
                <div class="box-body">
                    <?php echo Form::open(['route' => ['import.users.csv'],'enctype' => 'multipart/form-data', 'id' => 'form']); ?>

                    <?php echo e(Form::token()); ?>

                        <?php echo $__env->make('import.partials.file', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/import/index.blade.php ENDPATH**/ ?>