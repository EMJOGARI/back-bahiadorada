<div class="col-sm-6 col-xs-12">
    <div class="form-group">
      <?php echo Form::label('file', 'Data de Viviendas .CSV'); ?>

      <?php echo Form::file('file', ['class'=>'form-control']); ?>


    </div>
    <?php echo e(Form::button(
      '<i class="fa fa-save"></i> Guardar',
      [
        'type' => 'submit',
        'class' => 'btn btn-primary btn-sm',
        'disabled'=>'disabled',
        'data-toggle' => 'tooltip',
        'title' => 'Guardar'
      ]
      )); ?>

</div>
<?php $__env->startPush('scripts'); ?>
    <script>
        $("#file").change(function(){
            $("button").prop("disabled", this.files.length == 0);
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/import/vivienda/partials/file.blade.php ENDPATH**/ ?>