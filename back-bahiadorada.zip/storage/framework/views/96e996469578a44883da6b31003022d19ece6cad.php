<?php
    $i = $i . '-';
?>
<tr>
    <td><?php echo e($child_category->id); ?></td>
    <td><?php echo e($i . $child_category->name); ?></td>
    <td class="<?php echo e($child_category->statue == 1 ? 'bg-success' : 'bg-danger'); ?>"><?php echo e($child_category->statue == 1 ? 'Activo' : 'Inactivo'); ?></td>
    <td class="text-center">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.update')): ?>
            <a href="<?php echo e(URL::action('CategoryController@edit',encrypt($child_category->id))); ?>">
                <?php echo e(Form::button(
                    '<i class="fa fa-edit"></i>',
                    [
                        'type' => 'submit',
                        'class' => 'btn btn-primary btn-sm',
                        'data-toggle' => 'tooltip',
                        'title' => 'Editar'
                    ]
                )); ?>

            </a>
        <?php endif; ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.delete')): ?>
            <a href="#"
                data-target="#modal-delete-<?php echo e($child_category->id); ?>"
                data-toggle="modal" >
                <?php echo e(Form::button(
                    '<i class="fa fa-trash"></i>',
                    [
                        'class' => 'btn btn-warning btn-sm',
                            'data-toggle' => 'tooltip',
                            'title' => 'Eliminar'
                    ]
                )); ?>

            </a>
        <?php endif; ?>
    </td>
</tr>
<?php if($child_category->categories): ?>

        <?php $__currentLoopData = $child_category->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('category.partials.child_category', ['child_category' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\tradego\resources\views/category/partials/child_category.blade.php ENDPATH**/ ?>