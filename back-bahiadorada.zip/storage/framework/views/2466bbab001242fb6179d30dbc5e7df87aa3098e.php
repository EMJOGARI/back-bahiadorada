<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(trans('adminlte_lang::message.header')); ?></li>
            <!-- Optionally, you can add icons to the links -->
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bahia.list')): ?>
            <li class="<?php echo e(Request::is('bahia*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('bahia')); ?>">
                    <i class='fa fa-arrow-right'></i>
                    <span>BAHIA AL DIA</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('vivienda.list')): ?>
                <li class="<?php echo e(Request::is('viviendas*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('viviendas')); ?>">
                        <i class='fa fa-arrow-right'></i>
                        <span>Viviendas</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('estado-cuenta')): ?>
                <li class="<?php echo e(Request::is('estado-cuenta*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('estado-cuenta')); ?>">
                        <i class='fa fa-arrow-right'></i>
                        <span>Estado de Cuentas</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cuenta-contable')): ?>
                <li class="<?php echo e(Request::is('cuenta-contable*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('cuenta-contable')); ?>">
                        <i class='fa fa-arrow-right'></i>
                        <span>Cuenta Contables</span>
                    </a>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user.list','role.list','permission.list'])): ?>
                <li class="treeview <?php echo e(Request::is('usuarios*') || Request::is('roles*') || Request::is('permisos*') ? 'active' : ''); ?>">
                    <a href="#">
                        <i class='fa fa-users'></i>
                        <span>Usuarios</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.list')): ?>
                            <li class="<?php echo e(Request::is('usuarios*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('usuarios')); ?>">
                                    <i class='fa fa-arrow-right'></i>
                                    <span>Usuarios</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.list')): ?>
                            <li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('roles')); ?>">
                                    <i class='fa fa-arrow-right'></i>
                                    <span>Roles</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.list')): ?>
                            <li class="<?php echo e(Request::is('permisos*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(url('permisos')); ?>">
                                    <i class='fa fa-arrow-right'></i>
                                    <span>Permisos</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['import.csv'])): ?>
                <li class="treeview <?php echo e(Request::is('import*') ? 'active' : ''); ?>">
                    <a href="#">
                        <i class='fa fa-gears'></i>
                        <span>Importar Datos</span>
                        <i class="fa fa-angle-left pull-right"></i>
                    </a>
                    <ul class="treeview-menu">
                        <li class="<?php echo e(Request::is('import-users*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('import-users')); ?>">
                                <i class='fa fa-arrow-right'></i>
                                <span>Usuarios</span>
                            </a>
                        </li>
                        <li class="<?php echo e(Request::is('import-vivienda*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('import-vivienda')); ?>">
                                <i class='fa fa-arrow-right'></i>
                                <span>Viviendas</span>
                            </a>
                        </li>
                        <li class="<?php echo e(Request::is('import-edocta*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('import-edocta')); ?>">
                                <i class='fa fa-arrow-right'></i>
                                <span>Estados de Cuenta</span>
                            </a>
                        </li>
                        <li class="<?php echo e(Request::is('import-ctacont*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('import-ctacont')); ?>">
                                <i class='fa fa-arrow-right'></i>
                                <span>Cuenta Contable</span>
                            </a>
                        </li>
                        <li class="<?php echo e(Request::is('import-bahia*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('import-bahia')); ?>">
                                <i class='fa fa-arrow-right'></i>
                                <span>BAHIA AL DIA</span>
                            </a>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul><!-- /.sidebar-menu -->
        <div class="widget">
            <script src="https://apps.elfsight.com/p/platform.js" defer></script>
            <div class="elfsight-app-0d558f3a-751e-478f-8ead-1e067438e5c1"></div>
        </div>
    </section>

    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/vendor/adminlte/layouts/partials/sidebar.blade.php ENDPATH**/ ?>