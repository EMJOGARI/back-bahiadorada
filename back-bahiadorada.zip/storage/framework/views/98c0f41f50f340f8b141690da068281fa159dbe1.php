<?php $__env->startSection('htmlheader_title'); ?>
	Importar Datos Vivienda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Importar  Datos Vivienda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">
        <div class="col-md-12">

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> Importar Datos Vivienda</h3>
                </div>
                <div class="box-body">
                    <?php echo Form::open(['route' => ['import.vivienda.csv'],'enctype' => 'multipart/form-data', 'id' => 'form']); ?>

                    <?php echo e(Form::token()); ?>

                        <?php echo $__env->make('import.vivienda.partials.file', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/import/vivienda/index.blade.php ENDPATH**/ ?>