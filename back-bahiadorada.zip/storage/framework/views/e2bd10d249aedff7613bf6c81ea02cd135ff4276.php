<?php $__env->startSection('htmlheader_title'); ?>
	Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">

				<!-- Default box -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<h3 class="box-title">Lista de Roles </h3>
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.create')): ?>
							<a href="<?php echo e(url('roles/create')); ?>" class="pull-right">
								<?php echo e(Form::button(
									'<i class="fa fa-plus"></i> Nuevo Rol',
										[
											'type' => 'submit',
											'class' => 'btn btn-primary btn-sm',
											'data-toggle' => 'tooltip',
											'title' => 'Nuevo'
										]
								)); ?>

							</a>
						<?php endif; ?>
					</div>
					<div class="box-body">
						<?php echo $__env->make('roles.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/roles/index.blade.php ENDPATH**/ ?>