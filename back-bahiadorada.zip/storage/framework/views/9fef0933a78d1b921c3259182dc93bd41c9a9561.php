<?php $__env->startSection('htmlheader_title'); ?> 
	Permisos
<?php $__env->stopSection(); ?> 

<?php $__env->startSection('contentheader_title'); ?>
	Permisos
<?php $__env->stopSection(); ?>  

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">
        <div class="col-md-12">

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> Editar Permiso</h3>

                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i></button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i></button>
                    </div>
                </div>
                <div class="box-body">                    
                    <?php echo Form::model($permissions,['route' => ['permisos.update', encrypt($permissions->id)] ,'method' => 'PUT', 'enctype' => 'multipart/form-data', 'id' => 'form']); ?>                    
                    <?php echo e(Form::token()); ?>

                         <?php echo $__env->make('permisos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
                    <?php echo Form::close(); ?>                    			
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </div>
    </div>
</div>  
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\roles-permisos\resources\views/permisos/edit.blade.php ENDPATH**/ ?>