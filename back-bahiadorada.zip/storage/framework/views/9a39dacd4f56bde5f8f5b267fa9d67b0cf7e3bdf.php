<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
       
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 
        
    </strong> 
</footer>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/vendor/adminlte/layouts/partials/footer.blade.php ENDPATH**/ ?>