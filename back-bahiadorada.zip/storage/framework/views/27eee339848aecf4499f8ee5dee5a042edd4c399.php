<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar Menu -->
        <ul class="sidebar-menu" data-widget="tree">
            <li class="header"><?php echo e(trans('adminlte_lang::message.header')); ?></li>
            <!-- Optionally, you can add icons to the links -->
            <li class="<?php echo e(Request::is('home') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('home')); ?>">
                    <i class='fa fa-home'></i>
                    <span>Inicio</span>
                </a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cuotas.list')): ?>
                <li class="<?php echo e(Request::is('cuotas*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('cuotas')); ?>">
                        <i class='fa fa-arrow-right'></i>
                        <span>Resumen de Cuenta</span>
                    </a>
                </li>           
                <li class="<?php echo e(Request::is('cuotas*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('cuotas')); ?>">
                        <i class='fa fa-arrow-right'></i>
                        <span>Estado de Cuenta</span>
                    </a>
                </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('txt.')): ?>
            <li class="<?php echo e(Request::is('cuotas*') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('cuotas')); ?>">
                    <i class='fa fa-arrow-right'></i>
                    <span>Cargar Txt</span>
                </a>
            </li> 
            <?php endif; ?>
          
                     
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user.list','role.list','permission.list'])): ?>
            <li class="treeview <?php echo e(Request::is('usuarios*') || Request::is('roles*') || Request::is('permisos*') ? 'active' : ''); ?>">
                <a href="#">
                    <i class='fa fa-users'></i>
                    <span>Usuarios</span>
                    <i class="fa fa-angle-left pull-right"></i>
                </a>
                <ul class="treeview-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.list')): ?>
                    <li class="<?php echo e(Request::is('usuarios*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('usuarios')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Usuarios</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.list')): ?>
                    <li class="<?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('roles')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Roles</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.list')): ?>
                    <li class="<?php echo e(Request::is('permisos*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('permisos')); ?>">
                            <i class='fa fa-arrow-right'></i>
                            <span>Permisos</span>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\roles-permisos\resources\views/vendor/adminlte/layouts/partials/sidebar.blade.php ENDPATH**/ ?>