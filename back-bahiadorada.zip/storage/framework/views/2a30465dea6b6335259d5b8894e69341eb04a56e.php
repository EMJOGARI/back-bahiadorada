<?php $__env->startSection('htmlheader_title'); ?>
	Estado de Cuenta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Estado de Cuenta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<div class="container-fluid spark-screen">
		<div class="row">
			<div class="col-md-12">

				<!-- Default box -->
				<div class="box box-primary">
					<div class="box-header with-border">
						<div class="row">
							<div class="col-md-4">
								<h3 class="box-title">Cuotas - Saldo Pendiente: <?php echo e($pendiente); ?></h3>
							</div>
							<div class="col-md-8">
								<h5>A.- las cuotas ordinarias solo se pagarán en dólares efectivos o transferencia.</h5>
								<h5>B.- para el pago de su saldo pendiente debe regirse la tasa del día del Banco Central de Venezuela.</h5>
                            </div>
                            <div class="col-md-4">
								<?php echo $__env->make('estado-cuenta.partials.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
						</div>
					</div>
					<div class="box-body">
						<?php echo $__env->make('estado-cuenta.partials.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/estado-cuenta/index.blade.php ENDPATH**/ ?>