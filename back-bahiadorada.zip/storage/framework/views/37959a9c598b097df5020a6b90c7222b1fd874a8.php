<?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <strong><?php echo e(trans('adminlte_lang::message.message')); ?>!</strong><br><br>
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
	<strong>Whoops!</strong> <?php echo e(trans('adminlte_lang::message.someproblems')); ?><br><br>
	<ul>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li><?php echo e($error); ?></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/vendor/adminlte/layouts/partials/message.blade.php ENDPATH**/ ?>