<!DOCTYPE html>
<html>

<?php echo $__env->make('adminlte::layouts.partials.htmlheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

</html><?php /**PATH C:\laragon\www\tradego\resources\views/vendor/adminlte/layouts/auth.blade.php ENDPATH**/ ?>