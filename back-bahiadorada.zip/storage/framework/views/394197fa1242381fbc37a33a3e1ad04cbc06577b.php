<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.css')); ?>">
<?php $__env->stopPush(); ?>

<?php
  $i = '';
?>

<div class="row">
 <div class="col-sm-6 col-xs-12">
   <div class="form-group">
     <?php echo Form::label('name', '* Nombre'); ?>

     <?php echo Form::text('name', null, ['class'=>'form-control', 'placeholder'=>'Nombre...', 'required' => 'required']); ?>

   </div>
 </div>
 <div class="col-sm-6 col-xs-12">
   <div class="form-group">
     <label for="categoriy">Categoira padre</label>
     <select name="category_id" class="form-control select2" id="">
       <option value="">Seleccione...</option>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($rowcategory->id); ?>" <?php echo e(isset($category) && $category->category_id == $rowcategory->id ? 'selected' : ''); ?>><?php echo e($i . $rowcategory->name); ?></option>
          <?php $__currentLoopData = $rowcategory->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('category.partials.select.child_category', ['child_category' => $childCategory, $i], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </select>
   </div>
 </div>
 <div class="col-sm-6 col-xs-12">
   <div class="form-group">
    <?php echo Form::label('statue', '* Estatus'); ?>

    <?php echo e(Form::select('statue',[1 => 'Activo', 0 => 'Inactivo'], null , ['class' => 'form-control','required' => 'required'])); ?>

  </div>
</div>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
 <div class="form-group">
  <?php echo e(Form::button(
    '<i class="fa fa-save"></i> Guardar',
    [
      'type' => 'submit',
      'class' => 'btn btn-primary btn-sm',
      'data-toggle' => 'tooltip',
      'title' => 'Guardar'
    ]
    )); ?>

  <?php echo e(Form::button(
    '<i class="fa fa-close"></i> Cancelar',
    [
      'onclick'=>'history.back()',
      'type' => 'reset',
      'class' => 'btn btn-danger btn-sm',
      'data-toggle' => 'tooltip',
      'title' => 'Cancelar'
    ]
    )); ?>

  </div>
</div>
</div>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('plugins/select2/select2.js')); ?>"></script>
<script>
    $('.select2').select2();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles-permisos\resources\views/category/partials/form.blade.php ENDPATH**/ ?>