<?php $__env->startSection('htmlheader_title'); ?>
	Editar Perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	Editar Perfil
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">
        <div class="col-md-12">

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> Editar Usuarios</h3>
                </div>
                <div class="box-body">
                    <?php echo Form::model($user,['route' => ['usuarios.profile.update',encrypt($user->id)] ,'method' => 'PUT', 'id' => 'form']); ?>

                        <?php echo $__env->make('user.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\roles-permisos\resources\views/user/edit.blade.php ENDPATH**/ ?>