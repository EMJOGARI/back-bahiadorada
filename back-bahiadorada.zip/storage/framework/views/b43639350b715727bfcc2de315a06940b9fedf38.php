<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table">
    <thead>
        <th>Vivienda</th>
        <th>Fecha Emi.</th>
        <th>Fecha Ven.</th>
        <th>Fecha Pago</th>
        <th>Cuota</th>
        <th>Mora</th>
        <th>Saldo</th>
        <th>Tipo</th>
        <th>Status</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($dat->id_vivienda); ?></td>
                <td><?php echo e($dat->fe_emision); ?></td>
                <td><?php echo e($dat->fe_vencimiento); ?></td>
                <td><?php echo e($dat->fe_pago); ?></td>
                <td><?php echo e($dat->mo_cuota); ?></td>
                <td><?php echo e($dat->mora_cuota); ?></td>
                <td><?php echo e($dat->saldo_cuota); ?></td>
                <td><?php echo e($dat->tipo); ?></td>
                <td><?php echo e($dat->status); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable( {
            fixedHeader: true
        } );
    } );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/estado-cuenta/partials/list.blade.php ENDPATH**/ ?>