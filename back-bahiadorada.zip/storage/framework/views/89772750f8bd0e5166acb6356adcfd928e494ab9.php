<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/public/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<?php
    $i = '';
?>

<table class="table table-bordered data-table">
    <thead>
        <th width="10%">ID</th>
        <th width="20%">Nombre</th>
        <th width="30%">Estatus</th>
        <th width="20%">Acciones</th>
      </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->id); ?></td>
                <td><?php echo e($i . $category->name); ?></td>
                <td class="<?php echo e($category->statue == 1 ? 'bg-success' : 'bg-danger'); ?>"><?php echo e($category->statue == 1 ? 'Activo' : 'Inactivo'); ?></td>
                <td class="text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.update')): ?>
                        <a href="<?php echo e(URL::action('CategoryController@edit',encrypt($category->id))); ?>">
                            <?php echo e(Form::button(
                                '<i class="fa fa-edit"></i>',
                                    [
                                        'type' => 'submit',
                                        'class' => 'btn btn-primary btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Editar'
                                    ]
                            )); ?>

                        </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('category.delete')): ?>
                        <a href="#"
                            data-target="#modal-delete-<?php echo e($category->id); ?>"
                            data-toggle="modal" >
                            <?php echo e(Form::button(
                                '<i class="fa fa-trash"></i>',
                                    [
                                        'class' => 'btn btn-warning btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Eliminar'
                                    ]
                            )); ?>

                        </a>

                    <?php endif; ?>
                </td>
            </tr>
            <?php $__currentLoopData = $category->childrenCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('category.partials.child_category', ['child_category' => $childCategory, $i], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal modal-warning fade" id="modal-delete-<?php echo e($category->id); ?>">
        <?php echo Form::open(['method'=>'delete', 'route'=>['category.destroy', encrypt($category->id)]]); ?>

            <?php echo e(Form::token()); ?>

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                                <h4 class="modal-title">Eliminar category</h4>
                        </div>
                        <div class="modal-body">
                            <p>Confirme si desea Eliminar el Sector <strong><?php echo e($category->name); ?></strong></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-outline">Eliminar</button>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <?php echo Form::close(); ?>

        <!-- /.modal-dialog -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/public/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        /*var table = $('.data-table').DataTable( {
            fixedHeader: true
        } );*/
    } );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles-permisos\resources\views/category/partials/list.blade.php ENDPATH**/ ?>