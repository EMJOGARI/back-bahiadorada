<!-- Content Header (Page header) -->
<section class="content-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 content-header">
                <h1>
                    <?php echo $__env->yieldContent('contentheader_title', 'Page Header here'); ?>
                    <small><?php echo $__env->yieldContent('contentheader_description'); ?></small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> <?php echo e(trans('adminlte_lang::message.level')); ?></a></li>
                    <li class="active"><?php echo e(trans('adminlte_lang::message.here')); ?></li>
                </ol>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/vendor/adminlte/layouts/partials/contentheader.blade.php ENDPATH**/ ?>