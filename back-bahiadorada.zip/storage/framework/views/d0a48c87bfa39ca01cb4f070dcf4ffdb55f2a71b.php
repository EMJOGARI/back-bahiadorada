<!-- Compiled app javascript -->
<script src="<?php echo e(url (mix('/js/app.js'))); ?>"></script>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/vendor/adminlte/layouts/partials/scripts_auth.blade.php ENDPATH**/ ?>