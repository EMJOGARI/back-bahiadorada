<?php $__env->startSection('htmlheader_title'); ?>
	Viviendas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
    Resumen
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid spark-screen">
        <div class="row">
            <div class="col-md-12">
                <!-- Default box -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e($user->name); ?> </h3>
                    </div>
                    <!-- /.box-body -->
                    <div class="box-body">
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>Vivienda</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-home"></i></span>
                                    <input type="text" class="form-control" value="<?php echo e($vivienda->vivienda); ?>" disabled>
                                </div>
                             </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="form-group">
                                <label>E-mail</label>
                                <div class="input-group">
                                    <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                    <input type="text" class="form-control" value="<?php echo e($user->email); ?>" disabled>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <div class="col-md-12">
				<!-- Default box -->
				<div class="box box-primary">
					<div class="box-header with-border">
                    <h3 class="box-title">Cuotas - Saldo Pendiente: <?php echo e($pendiente); ?></h3>
					</div>
					<div class="box-body">
						<?php echo $__env->make('viviendas.partials.list-ctacon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<!-- /.box-body -->
				</div>
				<!-- /.box -->

			</div>








        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/viviendas/show.blade.php ENDPATH**/ ?>