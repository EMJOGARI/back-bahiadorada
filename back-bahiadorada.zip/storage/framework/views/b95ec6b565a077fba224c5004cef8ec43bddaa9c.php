<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.css')); ?>">
<?php $__env->stopPush(); ?>

<?php echo Form::open(array('url'=>'estado-cuenta', 'method'=>'GET', 'autocomplete'=>'off', 'role'=>'search' )); ?>

    <div class="input-group">
        <select name="livingplace" id="livingplace" class="form-control select2">
                <option value="">Seleccioné una Vivienda</option>
           <?php $__currentLoopData = $living; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $liv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($liv->vivienda); ?>"><?php echo e($liv->vivienda.' - '.$liv->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <span class="input-group-btn">
            <button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
        </span>
    </div>
<?php echo e(Form::close()); ?>


<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('plugins/select2/select2.js')); ?>"></script>
<script>
    $('.select2').select2();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/estado-cuenta/partials/search.blade.php ENDPATH**/ ?>