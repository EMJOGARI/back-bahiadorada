<?php $__env->startSection('htmlheader_title'); ?>
	Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contentheader_title'); ?>
	Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<div class="container-fluid spark-screen">
    <div class="row">
        <div class="col-md-12">

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title"> Crear Usuario</h3>
                </div>
                <div class="box-body">
                    <?php echo Form::open(['route' => ['usuarios.store'],'enctype' => 'multipart/form-data', 'id' => 'form']); ?>               
                    <?php echo e(Form::token()); ?>

                        <?php echo $__env->make('usuarios.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo Form::close(); ?>                   
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script>
  /** Referencia http://1000hz.github.io/bootstrap-validator/ */
  $('#form').validator()
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('adminlte::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\back-bahiadorada\resources\views/usuarios/create.blade.php ENDPATH**/ ?>