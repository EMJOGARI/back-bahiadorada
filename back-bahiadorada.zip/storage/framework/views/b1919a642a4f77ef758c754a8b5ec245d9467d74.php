<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('/public/plugins/DataTable/datatables.min.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopPush(); ?>
<table class="table table-bordered data-table">
    <thead>
        <th width="10%">ID</th>
        <th width="25%">Permiso</th>
        <th width="25%">Descripción</th>
        <th width="20%">Modulo</th>
        <th width="20%">Acciones</th>        
    </thead>
    <tbody>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($permiso->id); ?></td>
                <td><?php echo e($permiso->name); ?></td>
                <td><?php echo e($permiso->description); ?></td>
                <td><?php echo e($permiso->module); ?></td>
                <td class="text-center">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.update')): ?>
                        <a href="<?php echo e(URL::action('PermissionsController@edit', encrypt($permiso->id))); ?>">
                            <?php echo e(Form::button(
                                '<i class="fa fa-edit"></i>',
                                    [
                                        'type' => 'submit',
                                        'class' => 'btn btn-primary btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Editar'
                                    ]
                            )); ?>

                        </a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission.delete')): ?>
                        <a href="#"
                            data-target="#modal-delete-<?php echo e($permiso->id); ?>"
                            data-toggle="modal" >
                            <?php echo e(Form::button(
                                '<i class="fa fa-trash"></i>',
                                    [
                                        'class' => 'btn btn-warning btn-sm',
                                        'data-toggle' => 'tooltip',
                                        'title' => 'Eliminar'
                                    ]
                            )); ?>

                        </a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal modal-warning fade" id="modal-delete-<?php echo e($permiso->id); ?>">
        <?php echo Form::open(['method'=>'delete', 'route'=>['permisos.destroy', encrypt($permiso->id)]]); ?>

            <?php echo e(Form::token()); ?>

                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                                <h4 class="modal-title">Eliminar Rol</h4>
                        </div>
                        <div class="modal-body">
                            <p>Confirme si desea Eliminar el permiso <strong><?php echo e($permiso->name); ?></strong></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-outline">Eliminar</button>
                        </div>
                    </div>
                <!-- /.modal-content -->
                </div>
        <?php echo Form::close(); ?>

        <!-- /.modal-dialog -->
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('/public/plugins/DataTable/datatables.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
        var table = $('.data-table').DataTable( {
            fixedHeader: true
        } );
    } );
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\roles&permisos\resources\views/permisos/partials/list.blade.php ENDPATH**/ ?>